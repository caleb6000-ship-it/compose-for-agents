# Commit Instructions

The repository was not connected to this ChatGPT session, so these files were prepared as a repository-ready update rather than falsely claiming a GitHub push.

From the MeetCombo repository root in PowerShell:

```powershell
Copy-Item -Recurse -Force "PATH_TO_EXTRACTED_FOLDER\docs\*" ".\docs\"
Copy-Item -Recurse -Force "PATH_TO_EXTRACTED_FOLDER\scripts" ".\scripts"
git add docs scripts
git commit -m "docs: lock MeetCombo homepage acceptance criteria and workflow"
git push origin main
```

Review `package-json-scripts.example.json` and merge the listed scripts into the existing `package.json`; do not overwrite the entire file.

Then verify:

```powershell
npm install
npm run verify
npm run dev -- --port 3001
```

Open `http://localhost:3001`.
