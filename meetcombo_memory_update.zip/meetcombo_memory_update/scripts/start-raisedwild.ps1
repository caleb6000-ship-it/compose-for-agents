$ErrorActionPreference = 'Stop'

if (-not (Test-Path package.json)) {
  throw 'Run this script from the Raised Wild repository root.'
}

if (-not (Test-Path node_modules)) {
  npm install
}

Write-Host 'Starting Raised Wild at http://localhost:3000'
npm run dev -- --port 3000
