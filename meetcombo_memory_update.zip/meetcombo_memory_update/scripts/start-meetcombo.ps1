$ErrorActionPreference = 'Stop'

if (-not (Test-Path package.json)) {
  throw 'Run this script from the MeetCombo repository root.'
}

if (-not (Test-Path node_modules)) {
  npm install
}

Write-Host 'Starting MeetCombo at http://localhost:3001'
npm run dev -- --port 3001
