# MeetCombo Changelog

## 2026-07-15
### Added
- Converted the “Apple meets Iron Man” homepage concept into a pass/fail acceptance test.
- Added automatic rejection conditions for brochure-style and generic SaaS implementations.
- Established a mandatory workflow: read repository memory before coding, verify locally before merging, and record results afterward.
- Documented a pragmatic multi-tool strategy: ChatGPT for reasoning and documentation; Claude Code or Codex for bounded repository execution; GitHub as source of truth.
- Added local-development reliability requirements and explicit port conventions for Raised Wild and MeetCombo.

### Learned
- Corey and Luke demonstrated an AI-assisted GitHub workflow for School of Grit that researches the market and publishes daily blog posts. The first known post was June 26, 2026.
- Their workflow appears effective because it is narrow, repeatable, and grounded in GitHub.
- MeetCombo did not fail as an idea. The implementation drifted because important product decisions remained scattered across conversations and vague coding prompts.
- Permanent lesson: an extraordinary idea cannot survive on scattered conversation memory and vague coding prompts.

### Decision
- The current brochure-like MeetCombo homepage is not approved.
- The next implementation scope is limited to rebuilding the public front door and passing the acceptance test.
- Claude Code should be evaluated against Codex on the same task before changing the long-term tool stack.

## 2026-07-14
### Added
- Defined MeetCombo as “Apple meets Iron Man.”
- Defined the public homepage with two actions: **Meet Combo** and **Sign In**.
- Defined Meet Combo as the guided guest experience and Sign In as the transition into the user’s personal intelligence environment.
- Established `/docs/COMBO_INTERFACE_VISION.md` as the design north star.

### Risk Identified
- The project memory was not consistently copied into GitHub handoff, changelog, to-do, and daily notes, allowing implementation drift.

## 2026-07-13
### Direction
- Confirmed GitHub should be the shared source of truth across ChatGPT, Codex, Claude Code, and other tools.
- Established the intended memory structure: handoff, changelog, to-do, and daily notes.
- Confirmed MeetCombo is the operating system and intelligence layer; websites are supporting outputs, not the central product.
