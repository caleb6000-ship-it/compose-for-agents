# ChatGPT Handoff — MeetCombo

_Last updated: July 15, 2026_

## Source-of-Truth Rule
GitHub is the permanent project memory for MeetCombo. Important conversations must be translated into repository documents before another coding agent changes the product. Chat history alone is not an acceptable source of truth.

Required memory files:
- `/docs/CHATGPT_HANDOFF.md` — current product state, decisions, and active constraints.
- `/docs/CHANGELOG.md` — dated decisions and completed changes.
- `/docs/TODO.md` — prioritized next actions and acceptance gates.
- `/docs/daily/YYYY-MM-DD.md` — daily project notes and lessons.
- `/docs/COMBO_INTERFACE_VISION.md` — permanent product and design north star.

## Product North Star
MeetCombo is **Apple meets Iron Man**: a calm, cinematic, responsive intelligence environment. It must feel alive without feeling busy. It is not a brochure, generic SaaS landing page, dashboard, or feature catalog.

Permanent rule:
> Every screen should make the user feel more intelligent, never more overwhelmed.

## Public Entrance
The public homepage is the front door to the intelligence, not a marketing brochure.

It contains two primary actions only:
1. **Meet Combo** — dominant primary action.
2. **Sign In** — smaller, quieter, and directly beneath Meet Combo.

The user journey:
- **Meet Combo:** The visitor enters Combo's brain as a guided guest.
- **Sign In:** A returning user enters their own intelligence environment.
- **Personal Combo:** Combo acts as a Jarvis-like operator, guide, memory system, and intelligence communicator.

## Homepage Acceptance Test
The homepage is not approved unless every required item passes.

### Required visual state
- [ ] Initial viewport is predominantly black.
- [ ] Typography is white, precise, restrained, and highly legible.
- [ ] The screen uses substantial negative space.
- [ ] **Meet Combo** is the dominant action.
- [ ] **Sign In** is smaller and positioned beneath it.
- [ ] No feature grid, pricing section, service cards, testimonial carousel, blog feed, navigation-heavy header, or generic marketing copy appears in the opening experience.
- [ ] The composition feels cinematic and intentional on desktop and mobile.

### Required interaction
- [ ] Selecting **Meet Combo** begins a guided sequence rather than navigating to a conventional brochure page.
- [ ] The opening language may begin: “Hello. I’m Combo. Welcome. Let me show you how I think.”
- [ ] Text and visual elements appear with deliberate pacing.
- [ ] The environment gradually wakes up; it does not reveal everything at once.
- [ ] Motion communicates listening, thinking, connecting, remembering, prioritizing, revealing, or acting.
- [ ] The user can pause, skip, or continue the introduction without becoming trapped.
- [ ] Selecting **Sign In** clearly transitions from guest to owner.

### Required emotional result
- [ ] The user feels wonder first, understanding second, and ownership third.
- [ ] The user feels guided, not tested.
- [ ] The experience feels futuristic without neon cyberpunk clutter.
- [ ] The interface feels powerful without feeling intimidating.
- [ ] The final impression is “I entered an operating system,” not “I visited a startup website.”

### Automatic rejection conditions
Reject and redesign the implementation if any are true:
- [ ] It resembles a brochure or generic SaaS landing page.
- [ ] It leads with explanations instead of experience.
- [ ] It presents many cards, widgets, charts, or features at once.
- [ ] Motion is decorative rather than meaningful.
- [ ] The primary **Meet Combo** action is absent, unclear, or visually secondary.
- [ ] The product vision exists only in a chat prompt and is not represented in repository documentation and tests.

## Engineering Workflow
Before coding:
1. Read this file, `/docs/COMBO_INTERFACE_VISION.md`, `/docs/TODO.md`, and the latest daily note.
2. State which acceptance criteria the task will satisfy.
3. Limit each implementation assignment to a bounded scope.

Before merging:
1. Run lint, type checks, and production build.
2. Start the local development server and verify the public entrance manually.
3. Check desktop and mobile layouts.
4. Record the result in the changelog and daily note.
5. Do not mark the homepage complete until the acceptance test passes.

## AI Coding Tool Direction
Tool choice is pragmatic, not ideological.
- ChatGPT: product reasoning, durable documentation, architecture, planning, and review.
- Claude Code or Codex: repository implementation, testing, and bounded code changes.
- GitHub: permanent source of truth.
- Docker/local development: reproducible runtime and testing.

The team should compare Claude Code and Codex using the same bounded task, acceptance criteria, cost, test results, and code quality rather than choosing by a single demonstration.

## Local Development Reliability
Do not rely on repeatedly retyping uncertain commands. Use repository scripts.

Expected commands:
- `npm run dev` — starts the project on its default configured port.
- `npm run dev:raisedwild` — Raised Wild on port 3000.
- `npm run dev:meetcombo` — MeetCombo on port 3001.
- `npm run verify` — lint, type check, and production build.

If both projects are separate repositories, each repository should include a local `dev` script and the parent workspace may include the two explicit scripts above.

Warnings such as `GET / 200`, compilation timing, or Next.js smooth-scroll notices do not mean startup failed. The server is considered running when the terminal reports a local URL and the browser receives HTTP 200. Native dependency install scripts such as `sharp` must be approved once according to the package manager's security workflow.

## Current Priority
Rebuild only the MeetCombo public front door until the acceptance test passes. Do not expand into dashboards, feature pages, pricing, or broad product implementation before the entrance is correct.
