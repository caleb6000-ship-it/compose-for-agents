# MeetCombo To-Do

## P0 — Prevent Vision Loss
- [ ] Copy these files into the active MeetCombo repository.
- [ ] Confirm `/docs/COMBO_INTERFACE_VISION.md` exists and is referenced from the handoff.
- [ ] Commit with message: `docs: lock MeetCombo homepage acceptance criteria and workflow`.
- [ ] Require every coding agent to read the handoff, vision, to-do, and latest daily note before editing.

## P0 — Rebuild Public Front Door
- [ ] Remove brochure-style homepage sections from the initial experience.
- [ ] Build a predominantly black opening viewport.
- [ ] Add dominant **Meet Combo** action.
- [ ] Add smaller **Sign In** action beneath it.
- [ ] Implement the first guided sequence with deliberate pacing.
- [ ] Ensure mobile and desktop pass the homepage acceptance test.
- [ ] Capture screenshots or a short screen recording for review.
- [ ] Do not merge until all required acceptance boxes pass.

## P0 — Local Startup Reliability
- [ ] Confirm each project’s package manager from its lockfile.
- [ ] Add a stable `npm run dev` script to each repository.
- [ ] Reserve port 3000 for Raised Wild and 3001 for MeetCombo during simultaneous local development.
- [ ] Add `npm run verify` for lint, type check, and production build.
- [ ] Approve required native dependency install scripts once; document the exact command in the repository README.
- [ ] Add a startup script that checks dependencies, starts the correct port, and prints the browser URL.
- [ ] Never treat informational Next.js warnings as startup failures unless an error status or stack trace appears.

## P1 — Tool Evaluation
- [ ] Give Claude Code and Codex the same bounded homepage task.
- [ ] Compare total cost, time, tests passed, code quality, context retention, and amount of manual correction.
- [ ] Choose the implementation tool from evidence, not brand loyalty.

## P1 — Memory Discipline
- [ ] End every meaningful work session by updating handoff, changelog, to-do, and daily note.
- [ ] Add a pull-request checklist requiring documentation updates when product decisions change.
- [ ] Add a repository instruction file telling AI agents not to replace the guided experience with generic SaaS patterns.

## P2 — School of Grit Learning
- [ ] Review Corey and Luke’s daily-blog architecture.
- [ ] Document research source, review process, publishing schedule, quality controls, and failure handling.
- [ ] Identify what can be reused without copying their implementation blindly.
