# Caleb OS Shared Memory

This repository structure is the durable shared brain for Caleb's assistant system.

## What this pack contains

- A current handoff and operating state
- The Caleb OS vision
- Known people and workstreams
- Decisions, tasks, and a changelog
- Daily history files for July 4–13, 2026
- A verbatim transcript of the currently accessible July 13 chat
- A backfill register that clearly identifies missing source conversations
- Instructions for Codex and other assistants

## Truth standard

Never invent missing history. Label information as:

- **Verified** — present in an accessible transcript or source file
- **Reconstructed** — summarized from verified statements but not a full transcript
- **Unverified** — mentioned but not yet tied to an original source or date
- **Missing source** — no original chat/file is currently accessible

## First files every assistant should read

1. `AGENTS.md`
2. `docs/CHATGPT_HANDOFF.md`
3. `docs/CALEB_OS.md`
4. `docs/CURRENT_STATE.md`
5. `docs/TODO.md`
6. The newest file under `docs/history/`
