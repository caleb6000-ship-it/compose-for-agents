# To-Do

## Immediate

- [ ] Merge this memory pack into the correct GitHub repository.
- [ ] Confirm whether the new ChatGPT Project was created and record its exact name.
- [ ] Confirm the repository name, default branch, and whether Codex can commit or open a pull request.
- [ ] Backfill July 4–12 from original chats, shared links, screenshots, copied text, or other source files.
- [ ] Confirm whether the correct system name is Caleb OS, Kava iOS, or both.
- [ ] Recover and document the roles of Alex, Dan, and Kevin.
- [ ] Expand the MeetCombo architecture and product vision from original project materials.

## Ongoing session-close checklist

- [ ] Save a verbatim transcript when accessible.
- [ ] Summarize what was completed and handled.
- [ ] Record vision, key topics, turning points, ideas, and unresolved questions.
- [ ] Update people, projects, decisions, and next actions.
- [ ] Commit the memory update with an accurate date.

## Friday weekly sync

- [ ] Review the week's chats and daily files.
- [ ] Fill gaps while source conversations are still easy to find.
- [ ] Update current state and handoff.
- [ ] Commit or open a pull request.
