# History Index

## 2026

<details open>
<summary><strong>July 2026</strong></summary>

- [July 4](history/2026/07/2026-07-04.md) — missing source
- [July 5](history/2026/07/2026-07-05.md) — missing source
- [July 6](history/2026/07/2026-07-06.md) — missing source
- [July 7](history/2026/07/2026-07-07.md) — missing source
- [July 8](history/2026/07/2026-07-08.md) — missing source
- [July 9](history/2026/07/2026-07-09.md) — missing source
- [July 10](history/2026/07/2026-07-10.md) — missing source
- [July 11](history/2026/07/2026-07-11.md) — missing source
- [July 12](history/2026/07/2026-07-12.md) — missing source
- [July 13](history/2026/07/2026-07-13.md) — detailed reconstruction and transcript link

</details>
