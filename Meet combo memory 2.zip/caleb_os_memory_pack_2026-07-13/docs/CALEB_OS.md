# Caleb OS Vision

## Foundational idea

Caleb is building his assistants first because capable, connected assistants can help him learn, decide, sell, coordinate people, build websites, develop systems, and move faster across many businesses and projects.

The assistant system is not a side feature of a website. It is the operating layer that helps create and run the websites, businesses, sales systems, content systems, leadership systems, and future products.

## Desired outcome

A durable, expandable “brain” that can:

- Reconstruct context after a fresh session or device change
- Understand the long-term vision, not just the most recent task
- Track people, relationships, responsibilities, and commitments
- Preserve ideas, turning points, decisions, and why they mattered
- Keep daily work, completed work, and next actions synchronized
- Let ChatGPT and Codex use the same verified context
- Help Caleb learn while building
- Reduce repeated explanations and nightly manual resyncing

## System components

### GitHub — durable brain

Stores current truth, history, transcripts, decisions, people, projects, and assistant instructions in version-controlled files.

### ChatGPT Business — conversational intelligence

Supports planning, explanation, synthesis, learning, decision-making, and collaboration. A shared Project should contain related chats and files where available.

### Codex — implementation and repository operator

Reads repository instructions, edits files, builds software, and commits reviewed changes.

### MeetCombo — intended coordination layer

MeetCombo/Combo has been described as a future shared core-memory and coordination layer. The exact product architecture is not yet verified in the accessible source and should be expanded from original materials.

### Apple Notes — capture surface

Useful for quick capture and human browsing. It should feed the GitHub brain rather than compete with it as a second master source.

## People and organizational context

Alex, Dan, and Kevin are part of the larger concept, but their exact roles, relationships, and responsibilities are missing from the currently accessible transcript. See `PEOPLE.md` and backfill from original chats.

## Leadership philosophy

The accessible conversation references sales, building websites, and “building leaders, not followers, not founders.” Because the wording may reflect voice transcription, preserve it as a key phrase but do not reinterpret it until Caleb confirms the intended statement.

## Naming note

Earlier accessible messages use **Caleb OS**. The latest request says **Kava iOS**. Until confirmed, treat “Kava iOS” as a possible voice-transcription variant or a related name, not as a silent rename.
