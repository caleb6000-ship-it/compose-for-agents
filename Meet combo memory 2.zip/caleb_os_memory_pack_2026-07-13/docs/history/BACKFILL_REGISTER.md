# History Backfill Register

## Coverage goal

Preserve, at minimum, a word-for-word transcript and a structured summary for every working day.

## Current source audit

| Date | Verbatim source available | Summary status | Required action |
|---|---:|---|---|
| 2026-07-04 | No | Missing source | Locate original chat or notes |
| 2026-07-05 | No | Missing source | Locate original chat or notes |
| 2026-07-06 | No | Missing source | Locate original chat or notes |
| 2026-07-07 | No | Missing source | Locate original chat or notes |
| 2026-07-08 | No | Missing source | Locate original chat or notes |
| 2026-07-09 | No | Missing source | Locate original chat or notes |
| 2026-07-10 | No | Missing source | Locate original chat or notes |
| 2026-07-11 | No | Missing source | Locate original chat or notes |
| 2026-07-12 | No | Missing source | Locate original chat or notes |
| 2026-07-13 | Yes, current visible chat | Complete through latest captured user message | Append later messages after session |

## Accepted source methods

1. Move an eligible existing chat into the shared ChatGPT Project.
2. Open an old chat and create/update a shared link.
3. Copy the full conversation into a Markdown or text file.
4. Upload screenshots only as a last resort; transcribe and mark uncertain passages.
5. Add Apple Notes or other project files when they contain original dated material.

## Backfill procedure

For each recovered day:

1. Save the original text under `docs/transcripts/YYYY/MM/`.
2. Add a SHA-256 checksum if the source is a downloaded file.
3. Write the daily summary using only that source.
4. Update people, projects, decisions, current state, and tasks.
5. Change the date's status from **Missing source** to **Verified**.
