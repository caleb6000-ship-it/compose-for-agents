# People

This file records only verified information. Do not invent roles.

## Caleb Gonzalez

- Owner/operator of this assistant system and the person defining the vision
- Wants the assistants to function as an interconnected operating system
- Wants minimal manual intervention and reliable cross-device context

## Alex

- **Verified:** Named as important to the broader MeetCombo/Caleb OS concept
- **Role:** Not yet recovered from source conversations
- **Backfill needed:** Relationship, responsibilities, active projects, commitments, and current status

## Dan

- **Verified:** Named as important to the broader MeetCombo/Caleb OS concept
- **Role:** Not yet recovered from source conversations
- **Backfill needed:** Relationship, responsibilities, active projects, commitments, and current status

## Kevin

- **Verified:** Named as important to the broader MeetCombo/Caleb OS concept
- **Role:** Not yet recovered from source conversations
- **Backfill needed:** Relationship, responsibilities, active projects, commitments, and current status
