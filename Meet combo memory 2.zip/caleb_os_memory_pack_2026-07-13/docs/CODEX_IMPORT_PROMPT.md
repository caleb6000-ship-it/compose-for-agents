# Prompt to Give Codex

Merge the attached `caleb_os_memory_pack_2026-07-13` folder into the root of the current repository.

Requirements:

1. Preserve stronger existing content; merge instead of blindly overwriting.
2. Keep all Markdown files with LF line endings.
3. Place `AGENTS.md`, `.gitattributes`, `.editorconfig`, and `MEMORY_README.md` at the repository root. Merge with any existing equivalents rather than replacing stronger content.
4. Place the provided documentation under `docs/`.
5. Do not claim July 4–12 history is complete; keep those files marked `Missing source` until original chats are provided.
6. Verify links in `docs/HISTORY_INDEX.md` and the July 13 transcript link.
7. Show me the diff before committing.
8. If direct commits to `main` are allowed, commit with `docs(memory): initialize Caleb OS history through 2026-07-13`. Otherwise create a branch and pull request with that title.
