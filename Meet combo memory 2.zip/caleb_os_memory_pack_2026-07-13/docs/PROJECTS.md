# Projects and Workstreams

## Caleb OS / possible “Kava iOS” naming variant

- Interconnected assistant operating system
- Shared memory across ChatGPT, Codex, GitHub, Windows, and iPad
- Primary strategic priority

## MeetCombo / Combo

- Intended shared core-memory and coordination layer
- Exact product definition and architecture require backfill from original conversations and project files

## GitHub Shared Brain

- Durable repository-based memory
- Includes current state, handoff, people, projects, decisions, tasks, daily history, and transcripts

## Sales

- Important workstream mentioned by Caleb
- Specific offers, pipeline, process, owners, and metrics are not yet recovered

## Website Building

- Important output of the assistant system, not the central objective
- Specific sites and current status require backfill

## Leadership Development

- Key theme includes building leaders rather than followers
- Exact philosophy and wording require recovery from source conversations

## Grit & Mortar

- Mentioned as current context/work
- Detailed scope and status require source backfill

## School of Grit / School platform

- Mentioned as current context/work
- Detailed scope and status require source backfill

## GoHighLevel / CRM

- Mentioned as current context/work
- Detailed workflows and implementation status require source backfill

## Brand and Content Assets

Mentioned discoveries:

- Raising Core Statement
- Raised Outside / outdoor-community material
- Two matching character copies
- Starter practice brand assets

Exact filenames, locations, ownership, and dates are not yet verified.
