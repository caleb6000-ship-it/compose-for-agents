# ChatGPT Handoff

**Last verified update:** 2026-07-13  
**Primary source of truth:** GitHub  
**Working environment:** MeetCombo Business; user reports Pro selected  
**Core system name:** Caleb OS; the phrase “Kava iOS” was also spoken and needs naming confirmation

## Core objective

Build a connected assistant operating system that preserves context across iPad, Windows, ChatGPT Business, Codex, GitHub, and future MeetCombo capabilities. The assistants—not the websites—are the central product and force multiplier.

## Current operating model

- **GitHub:** durable source of truth and shared brain
- **ChatGPT Business:** conversation, reasoning, planning, learning, and coordination
- **Codex:** repository-aware implementation, file updates, commits, and code work
- **ChatGPT Project:** shared working context for related chats and files
- **Apple Notes:** quick capture/inbox and optional human-readable backup, not the master source

## Current known context

- Caleb wants minimal manual intervention.
- Windows and iPad must be able to reboot context from the same repository.
- The memory must include not only tasks, but also vision, people, turning points, ideas, decisions, and daily accomplishments.
- Important names mentioned: Alex, Dan, and Kevin. Their exact roles are not yet verified in accessible source material.
- Important themes/workstreams mentioned: MeetCombo, sales, websites, building leaders rather than followers, founders, Grit & Mortar, School of Grit, GoHighLevel, content, CRM, GitHub, and brand assets.
- Previously found material mentioned in the accessible chat includes a Raising Core Statement, Raised Outside/outdoor-community material, two matching character copies, and starter practice brand assets.
- A repository documentation structure was established around handoff, changelog, to-do, daily history, and transcripts.

## Known limitation

The currently accessible source contains the July 13 conversation only. No original July 4–12 conversations or File Library documents were available during this reconstruction. Those dates are represented honestly as missing-source records until their original chats are opened, moved into the Project, shared, or copied into the repository.

## Immediate next action

Merge this memory pack into the correct GitHub repository without overwriting stronger existing documents. Then use the backfill register to import July 4–12 one source chat at a time.
