# Changelog

## 2026-07-13

- Confirmed GitHub as the durable source of truth.
- Reframed the goal: the assistants are the core system; websites are supporting outputs.
- Established a shared-brain structure for ChatGPT, Codex, Windows, iPad, and MeetCombo.
- Added Caleb OS vision, people, projects, current state, decision log, to-do, history, and transcript files.
- Captured the currently visible conversation verbatim through the latest user request.
- Created honest missing-source records for July 4–12 rather than inventing history.
- Added LF line-ending rules to prevent recurring LF/CRLF churn across Windows and Apple devices.
