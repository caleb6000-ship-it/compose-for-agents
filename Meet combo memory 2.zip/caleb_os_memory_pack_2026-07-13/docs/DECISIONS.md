# Decision Log

## 2026-07-13 — GitHub is the durable source of truth

**Status:** Confirmed  
**Reason:** ChatGPT memory and separate device sessions are not a complete, dependable transcript archive.

## 2026-07-13 — Assistants are the core product

**Status:** Confirmed  
**Reason:** Caleb wants assistants to accelerate learning, building, selling, coordination, and leadership. Websites and other systems are supporting outputs.

## 2026-07-13 — Use structured memory files

**Status:** Confirmed  
**Files:** Handoff, vision, people, projects, current state, decisions, to-do, changelog, daily history, and transcripts.

## 2026-07-13 — Keep Apple Notes secondary

**Status:** Reconstructed from the conversation  
**Reason:** Notes may be used for quick capture and browsing, but a single source of truth is needed to avoid conflicting copies.

## 2026-07-13 — Weekly repository sync on Friday

**Status:** Requested by Caleb  
**Caution:** The repository update still requires a working automation, Codex workflow, or manual approval. Do not assume the commit occurred merely because a reminder was requested.

## 2026-07-13 — Do not fabricate missing history

**Status:** Required by the integrity of the system  
**Reason:** A useful brain must distinguish memory from invention.
