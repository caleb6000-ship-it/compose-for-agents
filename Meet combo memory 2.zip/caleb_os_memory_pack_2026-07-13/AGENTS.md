# Instructions for ChatGPT, Codex, and Other Assistants

## Mission

The assistants are the primary system being built. Websites, sales systems, content, CRM workflows, and other deliverables are outputs the assistants help Caleb learn, coordinate, and build.

## Required startup sequence

Before answering project questions or changing the repository, read:

1. `docs/CHATGPT_HANDOFF.md`
2. `docs/CALEB_OS.md`
3. `docs/PEOPLE.md`
4. `docs/PROJECTS.md`
5. `docs/CURRENT_STATE.md`
6. `docs/DECISIONS.md`
7. `docs/TODO.md`
8. The latest seven daily history files
9. The latest relevant transcript

## Required end-of-session sequence

After meaningful work:

1. Append verified events to today's daily history file.
2. Add decisions to `docs/DECISIONS.md`.
3. Update `docs/CURRENT_STATE.md` only when the present state changes.
4. Update `docs/TODO.md` with next actions and owners when known.
5. Add a concise entry to `docs/CHANGELOG.md`.
6. Preserve word-for-word transcripts under `docs/transcripts/` when the source is available.
7. Commit with a message such as `docs(memory): sync 2026-07-13`.

## Accuracy rules

- Never invent a role, date, decision, completed task, or conversation.
- Distinguish verified transcript facts from summaries and inference.
- Keep the original transcript append-only.
- Do not silently overwrite stronger existing documentation; merge it.
- Do not place passwords, API keys, private tokens, or other secrets in memory files.
- When the user says “remember this,” record durable project context in the appropriate repository file.
- If a term may be voice transcription—such as “Kava iOS” versus “Caleb OS”—preserve the wording and mark the naming question for confirmation.

## Cross-device rule

GitHub is the durable source of truth. ChatGPT Projects may hold working conversations and project memory, but no assistant may assume that ChatGPT memory is a complete transcript archive.

## Line endings

Use LF. The repository `.gitattributes` file normalizes Markdown and other text files to LF, including when edited on Windows.
