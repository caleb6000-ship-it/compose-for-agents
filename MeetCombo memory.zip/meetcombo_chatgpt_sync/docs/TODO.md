# To-Do

## Immediate
- [ ] Upload this starter structure to the correct GitHub repository.
- [ ] Merge any existing `docs/CHATGPT_HANDOFF.md` content rather than overwriting it.
- [ ] Review files and conversations from July 4, 2026 onward.
- [ ] Add verified daily summaries to each date file.
- [ ] Decide who or what process updates these files at the end of each work session.

## Ongoing
- [ ] Keep `CHATGPT_HANDOFF.md` limited to current truth.
- [ ] Record completed work and decisions in `CHANGELOG.md`.
- [ ] Keep next actions in `TODO.md`.
- [ ] Store daily conversation summaries under `docs/history/YYYY/MM/`.
