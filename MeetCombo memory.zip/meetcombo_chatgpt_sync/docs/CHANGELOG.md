# Changelog

## 2026-07-13
- Confirmed GitHub as the source of truth.
- Established standard handoff, changelog, to-do, and daily-history structure.
- Began rebuilding shared context between iPad and Windows.
- Identified the need for minimal-intervention syncing and reusable daily summaries.

## Earlier history
Daily files are included from 2026-07-04 onward. Add verified summaries as conversations and source files are reviewed.
