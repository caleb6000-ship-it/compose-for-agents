# ChatGPT Handoff

## Source of Truth
GitHub is the official source of truth for project context, decisions, progress, and next actions.

## Core Files
- `docs/CHATGPT_HANDOFF.md` — current project state
- `docs/CHANGELOG.md` — daily progress and decisions
- `docs/TODO.md` — next actions
- `docs/history/YYYY/MM/YYYY-MM-DD.md` — daily conversation summaries

## Current Known Context
- MeetCombo / Combo is intended to become the shared core-memory and coordination layer.
- Current work includes Grit & Mortar, School of Grit, GoHighLevel, School platform setup, content, CRM, GitHub, and brand assets.
- Known discovered files/assets include:
  - Raising Core Statement
  - Raised Outside / outdoor community material
  - Two matching character copies
  - Starter practice brand assets
- Existing project handoff material is stored under `docs/`.
- GitHub should be updated at the end of each meaningful work session.

## Operating Rule
Any ChatGPT session on Windows, iPad, or another device should begin by reading:
1. `docs/CHATGPT_HANDOFF.md`
2. `docs/TODO.md`
3. The latest entries in `docs/CHANGELOG.md`
4. The latest daily history note
