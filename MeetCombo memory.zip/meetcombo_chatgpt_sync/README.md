# MeetCombo ChatGPT Sync Starter

Upload the contents of this package into the root of the GitHub project.

Do not overwrite stronger existing documentation. Merge existing information into the matching files.
